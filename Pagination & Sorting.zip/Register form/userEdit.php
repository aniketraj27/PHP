<?php
$conn = mysqli_connect("localhost", "root", "");
$db = mysqli_select_db($conn, 'usermaster');
$showAlert = false;
$showError = false;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include '../Register Form/dbconnect.php';
if (isset($_POST['id'])) {
    $id = $_POST['id'];
    // $sql = "UPDATE 'usermaster' SET firstname='$_POST[firstname]',lastname='$_POST[lastname]',address='$_POST[address]', email='$_POST[email]', password='$_POST[password]', gender='$_POST[gender]',dob='$_POST[dob]',age='$_POST[age]',zipcode='$_POST[zipcode]',phone='$_POST[phone]' where id='$_POST[id]'" 
    $existssql = "UPDATE `usermaster` SET `id`='[id]',`firstname`='[firstname]',`lastname`='[lastname]',`address`='[address]',`email`='[email]',`password`='[password]',`gender`='[gender]',`dob`='[dob]',`age`='[age]',`zipcode`='[zipcode]',`mobileno`='[mobileno]' WHERE `id`='[id]'";
    $query_run = mysqli_query($conn, $existssql);
    if ($query_run) {
        // echo '<script type="text/javascript"> alert("Data Updated")</script>;
        $showAlert = true;

    } else {
        // echo '<script type="text/javascript"> alert("Data Not Updated")</script>';
        $showError = true;
       
    }
}
}
?>
<html>
<head>
    <title> User Edit </title>

    <!doctype html>
    <html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <link rel="stylesheet" href="./style.css">
        <title>Sign Up</title>
    </head>
<body>
    <?php
    require './nav.php';
    ?>
    <style>
        body {
            background-color: whitesmoke;
        }

        input {
            width: 40%;
            height: 5%;
            border: 1px;
            border-radius: 05px;
            padding: 8px 15px 8px 15px;
            margin: 10px 0px 15px 0px;
            box-shadow: 1px 1px 2px 1px grey;
        }
    </style>
    </head>
    <body>
        
        <center>
        <div class="container">
            <h2> Edit Your Info </h2>
            <form action="" method="POST">
                <input type="text" name="firstname" placeholder="Enter your Firstname" /><br />
                <input type="text" name="lastname" placeholder="Enter your Lastname" /><br />
                <input type="text" name="address" placeholder="Enter your Address" /><br />
                <input type="email" name="email" placeholder="Enter your email" /><br />
                <input type="password" name="password" placeholder="Enter your Password" /><br />
                <input type="text" name="gender" placeholder="Enter your Gender" /><br />
                <input type="date" name="dob" placeholder="Enter your Date of Birth" /><br />
                <input type="number" name="age" placeholder="Enter your Age" /><br />
                <input type="text" name="zipcode" placeholder="Zipcocde" /><br />
                <input type="number" name="mobileno" placeholder="Enter your Mobile No" /><br />

                <input type="submit" name="update" value="UPDATE DATA" />
            </form>
        </center>
</html>

