<?php
include '../Register Form/dbconnect.php';
?>


<html>
<head>
<title> User Table </title>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/style.css">
    <!-- <title>Welcome - <?php $_SESSION['firstname']?></title> -->
  </head>
  <body>
   <?php
//  include 'nav.php';
 ?>
  <!-- <div class="container my-5">
  <div class="alert alert-success" role="alert">
  <h4 class="alert-heading">Welcome - <?php echo $_SESSION['firstname']?></h4>
  <p>You've successfully loggedin,this is your profile.hope you were doing good during this pandemic and We are glad to see you back <?php echo $_SESSION['firstname']?></p>
  <hr>
  <p class="mb-0">Yoc can update the details by click on <b>Update Button</b></p>
</div>
  </div> -->
  <?php
  // $sql = "SELECT * FROM usermaster";
  // $result = mysqli_query($conn,$sql);
  //  $rows= mysqli_num_rows($result);
  // if (mysqli_num_rows($result) > 0) {
?>


<?php
  include 'nav.php';
  ?>
  <?php
  $sort = "ASC";
  $data_sort = "firstname";
  $data_sort = "lastname";
  $data_sort = "email";
  $data_sort = "dob";

  if (isset($_GET['sorting'])) {
    if ($_GET['sorting'] == 'ASC') {
      $sort = "DESC";
    } else {
      $sort = "ASC";
    }
  }
  if (isset($_GET['field_name'])  == 'firstname') {
    $data_sort = "firstname";
  } elseif (isset($_GET['field_name']) == 'lastname') {
    $data_sort = "lastname";
  } elseif (isset($_GET['field_name']) == 'email') {
    $data_sort = "email";
  } elseif (isset($_GET['field_name']) == 'dob') {
    $data_sort = "dob";
  }
  elseif (isset($_GET['field_name']) == 'id') {
    $data_sort = "id";
  }
  ?>
  <h2 class="text-center my-4">User Details</h2>
  <table class="table">
    <thead>
      <div class="table_container">
      <!DOCTYPE html>
	<html>
		<head>
			<title>Sorting</title>
			<meta charset="utf-8">
			<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
			<style>
			html {
				font-family: Tahoma, Geneva, sans-serif;
				padding: 50px;
			}
			table {
				border-collapse: collapse;
				width: 500px;
			}
			th {
				background-color: black;
				border: 1px solid #54585d;
			}
			th:hover {
				background-color: black;
			}
			th a {
				display: block;
				text-decoration:none;
				padding: 10px;
				color: #ffffff;
				font-weight: bold;
				font-size: 13px;
			}
			th a i {
				margin-left: 5px;
				color: rgba(255,255,255,0.4);
			}
			td {
				padding: 10px;
				color: #636363;
				border: 1px solid #dddfe1;
			}
			tr {
				background-color: #ffffff;
			}
			tr .highlight {
				background-color: #f9fafb;
			}
			</style>
		</head>
		<body>
        <tr>
          <th scope="col"><a class="header" href="index.php?sorting=<?php echo $sort; ?>&field_name=firstname">Firstname</a></th>
          <th scope="col"><a class="header" href="index.php?sorting=<?php echo $sort; ?>&field_name=lastname">Lastname</a></th>
          <th scope="col"><a class="header" href="index.php?sorting=<?php echo $sort; ?>&field_name=email">Email</a></th>
          <th scope="col"><a class="header" href="index.php?sorting=<?php echo $sort; ?>&field_name=dob">Date-of-Birth</a></th>
          <th colspan="2" class="text-center mr-3">Operations</th>
        </tr>
      </div>
    </thead>
    <tbody>
      <?php

      $records_per_page = 3;
      $sql = "SELECT * FROM `usermaster`";
      $result = mysqli_query($conn, $sql);
      $rows = mysqli_num_rows($result);
      $number_of_page = ceil($rows / $records_per_page);
      if (!isset($_GET['page'])) {
        $page = 1;
      } else {
        $page = $_GET['page'];
      }
     $limit_records = ($page - 1) * $records_per_page;
      $query = "SELECT * FROM `usermaster` ORDER BY  $data_sort $sort LIMIT $limit_records,$records_per_page";
      $result = mysqli_query($conn, $query);
      if ($rows > 0) {
        while ($data = mysqli_fetch_assoc($result)) {
      ?>
          <div class="table_container">
            <tr>
              <td><?php echo $data['firstname']; ?></td>
              <td><?php echo $data['lastname']; ?></td>
              <td><?php echo $data['email']; ?></td>
              <td><?php echo $data['dob']; ?></td>
              <td><a href="userEdit.php?id=<?php echo $data['id']; ?>" class="btn btn-sm btn-success">Update</a></td>
              <td><a href="userDelete.php?id=<?php echo $data['id']; ?>" class="btn btn-sm btn-danger confirmation" onclick="DeleteFunction()">Delete</a></td>
            </tr>
          </div>
      <?php
        }
      }
      ?>
      <?php
      if (isset($_GET['sorting'])) {
        if ($_GET['sorting'] == 'ASC') {
          $sort = "ASC";
        } else {
          $sort = "DESC";
        }
      }
      ?>
    </tbody>
  </table>
  </table>
  <div class="but">
  <?php
  for ($page = 1; $page <= $number_of_page; $page++) {
    echo '<a class="btn btn-outline-secondary page" href = "index.php?page=' . $page . '">' . $page . ' </a>
    ';
  }
  ?>
  </div>
</body>
<script type="text/javascript">
        var elems = document.getElementsByClassName('confirmation');
        var confirmIt = function(e) {
          if (!confirm('Are you sure, You want to Delete it?')) e.preventDefault();
        };
        for (var i = 0, l = elems.length; i < l; i++) {
          elems[i].addEventListener('click', confirmIt, false);
        }
      </script>

</html>
