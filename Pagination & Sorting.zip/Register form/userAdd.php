<?php
$showAlert = false;
$showError = false;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include '../Register Form/dbconnect.php';
    $firstname = $_POST["firstname"];
    $lastname = $_POST["lastname"];
    $address = $_POST["address"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $cpassword = $_POST["cpassword"];
    $gender = $_POST["gender"];
    $dob = $_POST["dob"];
    $age = $_POST["age"];
    $zipcode = $_POST["zipcode"];
    $mobileno = $_POST["mobileno"];
    $exists = false;
    // check whether the username exist or
    $existssql = "SELECT * FROM `usermaster` WHERE email='$email'";
    $result = mysqli_query($conn, $existssql);
    $numExistRows = mysqli_num_rows($result);
    if($numExistRows > 0){
        $showError = "User Already Exists";
    }
    else if($firstname == "" || $lastname == "" || $email == "" || $address=="" || $password == "" || $gender == "" || $dob =="" || $age =="" || $zipcode =="" || $mobileno == ""){
        $showError = "Enter proper details";
    }
     else if (($password == $cpassword) && $exists == false) {
         $hash = password_hash($password,PASSWORD_DEFAULT);
        $sql = "INSERT INTO `usermaster` (`firstname`, `lastname`, `address`, `email`, `password`, `gender`, `dob`, `age`, `zipcode`, `mobileno`) VALUES ('$firstname', '$lastname', '$address', '$email', '$password', '$gender', '$dob', '$age', '$zipcode', '$mobileno')
        ";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            $showAlert = true;
        }
    }
}

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="./style1.css">
    <title>Sign Up</title>
  </head>
  <body>
   <?php
     require './nav.php';
   ?>
    <?php
if ($showAlert) {
  echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
<strong>Successfully!</strong>your account as been registerd
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';
}
if ($showError) {
  echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
<strong>warning!</strong> '. $showError .'
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';
}
?>
   <div class="container" >
       <h2 class="text">Registration Form</h2>
    <form action ="../Register Form/userAdd.php" method="post">

  <div class="container col mb-3 col-md-5">
    <label for="firstname" class="form-label">First Name :</label>
    <input type="text" class="form-control" name="firstname" id="firstname" >
  </div>

  <div class="container mb-3 col-md-5">
    <label for="lastname" class="form-label">Last Name :</label>
    <input type="text" class="form-control" name="lastname" id="lastname" >
  </div>

  <div class="container mb-3 col-md-5">
    <label for="address" class="form-label">Address :</label>
    <input type="text" class="form-control" name="address" id="address" >
  </div>

  <div class="container mb- col-md-5">
    <label for="email" class="form-label">Email :</label>
    <input type="email" class="form-control" name="email" id="email" >
  </div>

  <div class="container mb-3 col-md-5">
    <label for="password" class="form-label">Password :</label>
    <input type="password" name="password" class="form-control">
  </div>

  <div class="container mb-3 col-md-5">
      <label for="cpassword" class="form-label">Confirm Password</label>
      <input type="password" name="cpassword" class="form-control">
      <div id="cpassword" class="form-text">Enter the password same as above.</div>
  </div>

  <div class="container mb-3 col-md-5">
    <label for="gender" class="form-label">Gender :</label>
    <input type="text" class="form-control" name="gender" id="gender">
  </div>

  <div class="container mb-3 col-md-5">
    <label for="dob" class="form-label">Date of Birth :</label>
    <input type="date" class="form-control" name="dob" id="dob" >
  </div>

  <div class="container mb-3 col-md-5">
    <label for="age"  class="form-label">Age :</label>
    <input type="number" name="age" class="form-control">
  </div>

  <div class="container mb-3 col-md-5">
    <label for="zipcode" class="form-label">Zipcode :</label>
    <input type="text" class="form-control" name="zipcode" id="zipcode" >
  </div>

  <div class="container mb-3 col-md-5">
    <label for="mobileno" class="form-label">Mobile Number :</label>
    <input type="number" class="form-control" name="mobileno" id="mobileno" >
  </div>
  <center>
  <button type="submit" class="btn btn-primary col mb-3 col-md-2">Register</button>
</center>
</form>
</div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>